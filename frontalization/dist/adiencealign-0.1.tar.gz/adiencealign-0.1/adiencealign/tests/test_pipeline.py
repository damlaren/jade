'''
Created on May 8, 2014

@author: eran
'''
import unittest
import glob
from adiencealign.cascade_detection.cascade_face_finder import CascadeFaceFinder
from adiencealign.affine_alignment.affine_aligner import AffineAligner
import os
from adiencealign.landmarks_detection.landmarks_detector import detect_landmarks
from adiencealign.common.landmarks import read_fidu, unwarp_fidu, draw_fidu
import cv2
from adiencealign.pipeline.CascadeFaceAligner import CascadeFaceAligner

class Test(unittest.TestCase):


    def testPipeline(self):
        '''
        there is no assert here, just observe the outputs in tests/outputs/pipeline/
        '''
        NUM = 3

        #input_folder = '/home/albert/Desktop/frontalization_multiple/' + str(NUM) + '/adiencealign/tests/resources/pipeline/'
        #faces_folder = '/home/albert/Desktop/frontalization_multiple/' + str(NUM) + '/adiencealign/tests/outputs/pipeline/faces/'
        #aligned_folder = '/home/albert/Desktop/frontalization_multiple/' + str(NUM) + '/adiencealign/tests/outputs/pipeline/aligned/'

        input_folder = '/media/albert/NewVolume/face_project/' + str(NUM) + '/resources/pipeline/'
        faces_folder = '/media/albert/NewVolume/face_project/' + str(NUM) + '/outputs/pipeline/faces/'
        aligned_folder = '/media/albert/NewVolume/face_project/' + str(NUM) + '/outputs/pipeline/aligned/'
        cascade_face_aligner = CascadeFaceAligner()
        
        # detect cascade           
        cascade_face_aligner.detect_faces(input_folder, faces_folder)
        cascade_face_aligner.align_faces(input_images = faces_folder,
                                         output_path = aligned_folder, 
                                         fidu_max_size = 500*500, 
                                         fidu_min_size = 25*25, 
                                         is_align = True, 
                                         is_draw_fidu = True, 
                                         delete_no_fidu = True)
                
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testPipeline']
    unittest.main()
